import mongoose from "mongoose";
import cors from 'cors'
import express from 'express'
import bodyParser from 'body-parser'
import route from "./Components/Route.js";


const app = express()

app.use(cors());
app.use(bodyParser.json());

URL = "mongodb://localhost:27017/newtodo"

mongoose.connect(URL).then(() => {
    console.log("connected to database")

    app.listen(5000, () =>{
        console.log("server is running on 5000 port")
    })
}).catch(error => console.log(error))

app.use('/api', route)