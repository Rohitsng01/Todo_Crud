import Data from "./Model.js";

export const create = async(req,res)=> {
    try {
        const user = new Data(req.body)
        if(!user){
            return res.status(404).json({msg:'Data Not found'})
        }
        const saveData = await user.save()
        // console.log(JSON.stringify(saveData))
        res.status(200).json({msg:"Data saved Succesfully", data:saveData}
        )
        
    } catch (error) {
        res.status(500).json({msg:'Server Error',error:error})
    }
}

export const get = async(req,res)=>{
    try {
        const user = await Data.find()
        if(!user){
            return res.status(404).json({msg:'Data Not Found'})
        }
        res.status(200).json(user)
        
    } catch (error) {
        res.status(500).json(error)
    }
}

export const getone = async(req,res)=> {
    try {
        const {id} = req.params
        const user = await Data.findById(id)
        if(!user){
            return res.status(404).json({msg:'Data Not Found'})
        }
        res.status(200).json(user)
    } catch (error) {
        res.status(500).json(error)
    }
}
export const update = async(req,res)=> {
    try {
        const {id} = req.params
        const user = await Data.findById(id)
        if(!user){
            return res.status(404).json({msg:'Data Not Found'})
        }
        const updateData = await Data.findByIdAndUpdate(id,req.body,{new:true})
        res.status(200).json({msg:'Data updated Succesfully', data:updateData})
        
    } catch (error) {
        res.status(500).json(error)
    }
}

export const deleteHandle = async(req,res)=> {
    try {
        const {id} = req.params
        const user = await Data.findById(id)
        if(!user){
            return res.status(404).json({msg:'Data Not Found'})
        }
        const deleteData = await Data.findByIdAndDelete(id)
        res.status(200).json({msg:'Data Deleted Succesfully' , data:deleteData})
        
    } catch (error) {
        res.status(500).json(error)
    }
}

export const complete = async(req,res)=> {
    try {
        // console.log("id reached")
        const {id} = req.params
        const data = await  Data.findById(id)
        
        if(!data){
            return res.status(404).json({msg:'Data Not Found'})
            }
            const newStatus = data.status === 'complete' ? 'todo' : 'complete';
            const complete = await Data.findByIdAndUpdate(id,{status: newStatus}, {new:true})
            res.status(200).json({msg:'Data updated Succesfully', data:complete})
        
    } catch (error) {
        console.log(error)
        res.status(500).json(error)
    }
}