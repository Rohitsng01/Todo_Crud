import express from 'express'
import { complete, create, deleteHandle, get, getone, update } from './Api.js'

const route = express.Router()

route.post('/create', create)
route.get('/get', get)
route.get('/getone/:id', getone)
route.put('/update/:id', update)
route.delete('/delete/:id', deleteHandle)
route.post('/complete/:id', complete)


export default route
