import mongoose from "mongoose";

const Data = new mongoose.Schema({
    title:{
        type:String,
        required:true
    },
    disc:{
        type:String,
        required:true
    },
    status: {
        type: String,
        default: 'todo'
    }

})
export default mongoose.model("Server",Data);